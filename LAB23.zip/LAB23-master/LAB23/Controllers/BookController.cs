﻿using LAB23.Models;
using System.Collections.Generic;
using System.Web.Mvc;

namespace LAB23.Controllers
{
    public class BookController : Controller
    {
        // GET: Book
        public string Jacob()
        {
            return " Welcome back Jacob ! ";
        }

        public ActionResult ListBook()
        {
            var books = new List<string>();
            books.Add("Doremon 1 - Fujiko Fujio ");
            books.Add("Doremon 2 - Fujiko Fujio");
            books.Add("Doremon 3 - Fujiko Fujio ");
            ViewBag.Books = books;
            return View();
        }
        public ActionResult ListBookModel()
        {
            var books = new List<Book>();
            books.Add(new Book(1, "Doremon 1", "Fujiko Fujio ", "/Content/Images/book1cover.png"));
            books.Add(new Book(2, "Doremon 2", "Fujiko Fujio", "/Content/Images/book2cover.png"));
            books.Add(new Book(3, "Doremon 3", "Fujiko Fujio ", "/Content/Images/book3cover.png"));
            return View(books);
        }
        public ActionResult EditBook(int id)
        {
            var books = new List<Book>();
            books.Add(new Book(1, "Doremon 1", "Fujiko Fujio ", "/Content/Images/book1cover.png"));
            books.Add(new Book(2, "Doremon 2", "Fujiko Fujio", "/Content/Images/book2cover.png"));
            books.Add(new Book(3, "Doremon 3", "Fujiko Fujio ", "/Content/Images/book3cover.png"));

            Book book = new Book();
            foreach (Book b in books)
            {
                if (b.Id == id)
                {
                    book = b;
                    break;
                }
            }
            if (book == null)
            {
                return HttpNotFound();
            }
            return View(book);
        }

        [HttpPost, ActionName("EditBook")]
        [ValidateAntiForgeryToken]
        public ActionResult EditBook(int id, string Title, string Author, string ImageCover)
        {
            var books = new List<Book>();
            books.Add(new Book(1, "Doremon 1", "Fujiko Fujio ", "/Content/Images/book1cover.png"));
            books.Add(new Book(2, "Doremon 2", "Fujiko Fujio", "/Content/Images/book2cover.png"));
            books.Add(new Book(3, "Doremon 3", "Fujiko Fujio ", "/Content/Images/book3cover.png"));
            if (id == null)
            {
                return HttpNotFound();
            }
            foreach (Book b in books)
            {
                if (b.Id == id)
                {
                    b.Title = Title;
                    b.Author = Author;
                    b.Imagecover = ImageCover;
                    break;
                }
            }
            return View("ListBookModel", books);
        }

        public ActionResult CreateBook()
        {
            return View();
        }

        [HttpPost, ActionName("CreateBook")]
        [ValidateAntiForgeryToken]

        public ActionResult Contact([Bind(Include = " Id,Title,Author,ImageCover")] Book book)
        {
            var books = new List<Book>();
            books.Add(new Book(1, "Doremon 1", "Fujiko Fujio ", "/Content/Images/book1cover.png"));
            books.Add(new Book(2, "Doremon 2", "Fujiko Fujio", "/Content/Images/book2cover.png"));
            books.Add(new Book(3, "Doremon 3", "Fujiko Fujio ", "/Content/Images/book3cover.png"));
            try
            {
                if(ModelState.IsValid)
                {
                    books.Add(book);
                }
            }
            catch (RetryLimitExceededException)
            {
                 ModelState.AddModelError("", "Error");
            }
         return View("ListBookModel", books);
       }
    }
}